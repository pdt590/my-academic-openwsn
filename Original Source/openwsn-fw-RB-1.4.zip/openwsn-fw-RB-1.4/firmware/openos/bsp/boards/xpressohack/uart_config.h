/**
\brief Cross-platform declaration "UART" specific LPCXpresso config bsp module.

\author Xavi V <watteyne@eecs.berkeley.edu>, February 2012.
*/

#ifndef UART_CONFIG_H_
#define UART_CONFIG_H_



#endif /* UART_CONFIG_H_ */

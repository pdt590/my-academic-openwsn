/**
\brief iot-lab_M3 definition of the "exti" bsp module.

\author Alaeddine Weslati <alaeddine.weslati@inria.fr>, January 2014.
*/

// Includes ------------------------------------------------------------------*/
#include "stm32f10x_lib.h"
#include "stm32f10x_gpio.h"

void Exti_Init(void)
{
}


/*
 * File:    startup.h
 * Purpose: Determine cause of Reset and which processor is running
 *
 * Notes:   
 */

#ifndef _STARTUP_H_
#define _STARTUP_H_

/********************************************************************/

void common_startup(void);

/********************************************************************/

#endif /* _STARTUP_H_ */

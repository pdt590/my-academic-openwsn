
Connect Telosb to your USB port and execute:

python bsl --telosb -c /dev/ttyUSB0 -r -e -I -p test_leds_xtal.ihex

#include <hidef.h> /* for EnableInterrupts macro */
#include "derivative.h" /* include peripheral declarations */





void main(void) {
   
  /* include your code here */

  for(;;) {
    
  } /* loop forever */
  /* please make sure that you never leave main */
}

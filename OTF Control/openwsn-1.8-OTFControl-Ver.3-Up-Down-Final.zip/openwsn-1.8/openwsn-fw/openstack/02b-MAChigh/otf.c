#include "opendefs.h"
#include "otf.h"
#include "neighbors.h"
#include "sixtop.h"
#include "scheduler.h"
#include "openqueue.c"
#include "idmanager.h"


//=========================== variables =======================================

//=========================== prototypes ======================================

void otf_addCell_task(void);
void otf_removeCell_task(void);
// otf duythang
void otf_sendDatagramUp_task(void);
void otf_sendDatagramDown_task(void);

//=========================== public ==========================================

void otf_init(void) {
}

void otf_notif_addedCell(void) {
   scheduler_push_task(otf_addCell_task,TASKPRIO_OTF);
}

void otf_notif_removedCell(void) {
   scheduler_push_task(otf_removeCell_task,TASKPRIO_OTF);
}

void otf_notif_sendedDatagramUp(void) {  
   scheduler_push_task(otf_sendDatagramUp_task,TASKPRIO_OTF);
}

void otf_notif_sendedDatagramDown(void) {
   scheduler_push_task(otf_sendDatagramDown_task,TASKPRIO_OTF);
}


//=========================== private =========================================

void otf_addCell_task(void) {
   open_addr_t          neighbor;
   bool                 foundNeighbor;
   
   // get preferred parent
   foundNeighbor = neighbors_getPreferredParentEui64(&neighbor);
   if (foundNeighbor==FALSE) {
      return;
   }
   
   // call sixtop
   sixtop_addCells(
      &neighbor,
      1
   );
}

void otf_removeCell_task(void) {
   open_addr_t          neighbor;
   bool                 foundNeighbor;
   		

   // get preferred parent
   foundNeighbor = neighbors_getPreferredParentEui64(&neighbor);
   if (foundNeighbor==FALSE) {
      return;
   }
   
   // call sixtop
   sixtop_removeCell(
      &neighbor
   );
}

void otf_sendDatagramUp_task(void){	
   open_addr_t          neighbor;
   bool                 foundNeighbor;
   
   uint8_t				nbrIdx;
   uint8_t				child_nbr_count;
   OpenQueueEntry_t*    datagram;
   
   child_nbr_count = 0;
   datagram = openqueue_sixtopGetDatagram(); 
  
   if(!idmanager_getIsDAGroot()){
   		sixtop_processDatagram(datagram);
   	}
   
   for (nbrIdx=0;nbrIdx<MAXNUMNEIGHBORS;nbrIdx++) {
		if ((neighbors_isNeighborWithHigherDAGrank(nbrIdx))==TRUE) {
			   
		   child_nbr_count++;
		   neighbors_getNeighbor(&neighbor,ADDR_64B,nbrIdx);
		   sixtop_sendDatagram_Up(&neighbor);
					   
		}
	}

	if (child_nbr_count==0){
	
		foundNeighbor = neighbors_getPreferredParentEui64(&neighbor);
   		if (foundNeighbor==FALSE) {
     		 return;
  		}
   		 //call sixtop
   		sixtop_sendDatagram_Down(&neighbor);
		openqueue_freePacketBuffer(datagram); 
	}
    else{
		
		child_nbr_count = 0;
		openqueue_freePacketBuffer(datagram);
			
    }
	
}
void otf_sendDatagramDown_task(void){
   open_addr_t          neighbor;
   bool                 foundNeighbor;
   OpenQueueEntry_t*    datagram;
   
   datagram = openqueue_sixtopGetDatagram(); 

  if(idmanager_getIsDAGroot()){

  	//openserial_printData(datagram, datagram->length);
  	openserial_printInfo(COMPONENT_SIXTOP,
						 ERR_PAYLOAD_LENGTH,
					    (errorparameter_t)50,
						(errorparameter_t) 0);  		
  }
   
  //get preferred parent
  foundNeighbor = neighbors_getPreferredParentEui64(&neighbor);
   if (foundNeighbor==FALSE) {
      return;
  }
   
    //call sixtop
   sixtop_sendDatagram_Down(&neighbor);
   openqueue_freePacketBuffer(datagram);
}



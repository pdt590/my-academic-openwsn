#include "opendefs.h"
#include "uecho.h"
#include "openudp.h"
#include "openqueue.h"
#include "openserial.h"
#include "packetfunctions.h"



#include "sixtop.h"
#include "idmanager.h"
#include "neighbors.h"


//=========================== variables =======================================

//=========================== prototypes ======================================

//=========================== public ==========================================

void uecho_init() {
}

void uecho_receive(OpenQueueEntry_t* request) {
   uint16_t          temp_l4_destination_port;
   OpenQueueEntry_t* reply;
   
   open_addr_t       neighbor;
   bool              foundNeighbor;

   /*----------------------Send confirm-------------------------------------
   reply = openqueue_getFreePacketBuffer(COMPONENT_UECHO);
	  if (reply==NULL) {
		 openserial_printError(
			COMPONENT_UECHO,
			ERR_NO_FREE_PACKET_BUFFER,
			(errorparameter_t)0,
			(errorparameter_t)0
		 );
		 return;
	  }

   reply->owner                         = COMPONENT_UECHO;
   
   // reply with the same OpenQueueEntry_t
   reply->creator                       = COMPONENT_UECHO;
   reply->l4_protocol                   = IANA_UDP;
   temp_l4_destination_port             = request->l4_destination_port;
   reply->l4_destination_port           = request->l4_sourcePortORicmpv6Type;
   reply->l4_sourcePortORicmpv6Type     = temp_l4_destination_port;
   reply->l3_destinationAdd.type        = ADDR_128B;
   
   // copy source to destination to echo.
   memcpy(&reply->l3_destinationAdd.addr_128b[0],&request->l3_sourceAdd.addr_128b[0],16);
   
   packetfunctions_reserveHeaderSize(reply,1); // add confirm packet
   memcpy(&reply->payload[0],confirm,1);
   openqueue_freePacketBuffer(request);
   
   if ((openudp_send(reply))==E_FAIL) {
      openqueue_freePacketBuffer(reply);
   }
   
   //---------------------------------------------------------------------*/
   
 /*---------------------------------------------------------------------
   

   // |--TYPE--|-----DATA-----|
   if((request->payload[0])=='A'){
   		
		packetfunctions_tossHeader(request,1);// delete 1 byte for TYPE	
   		request->creator = COMPONENT_SIXTOP_RES;
   		request->owner   = COMPONENT_COMMAND_STORAGE;
   
   		sixtop_sendControlCommand();
   }
   else if (request->payload[0]=='S'){
   	
   	    packetfunctions_tossHeader(request,1);// delete 1 byte for TYPE	
		request->creator = COMPONENT_SIXTOP_RES;
		request->owner   = COMPONENT_DATA_STORAGE;
		sixtop_sendSensorData();
		
   }
   
   //----------------------------------------------------------------*/
   

}

void uecho_sendDone(OpenQueueEntry_t* msg, owerror_t error) {
   openqueue_freePacketBuffer(msg);
}

bool uecho_debugPrint() {
   return FALSE;
}

//=========================== private =========================================

/**
\brief <TODO, 1-2 lines>

<TODO, what to buy>

<TODO, how to connect the TelosB to the buzzer>

<TODO, how to build the binary>

<TODO, what to expect when it runs>
 
\author <TODO, name> <TODO, e-mail>, <TODO date>
*/

#include "msp430f1611.h"
#include "stdint.h"

int main(void) {
   // TODO
}


#ifndef __CONFIGURERADIO_H
#define __CONFIGURERADIO_H

void    radio_configure();

#endif
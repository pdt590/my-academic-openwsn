The OpenWSN firmware is documented using [http://www.stack.nl/~dimitri/doxygen/](doxygen) syntax. This folder contains the configuration for Doxygen to build HTML-based documentation.

Note that this documentation is built nightly and published at http://openwsn-berkeley.github.io/firmware/ by the OpenWSN build servers.